# Internship Task 4 Submission

This package contains all required files for Task 4 (E-commerce Database).

## Files Included
- **task4_ecommerce.sql** → Schema + sample data (5–10 rows) + queries.
- **screenshots/** → Mock SQL execution screenshots.
- **task4_submission_presentation.pptx** → PowerPoint with task explanation and screenshots.
- **README.md** → Documentation of contents.

## How to Use
1. Import `task4_ecommerce.sql` into MySQL.
2. Run the queries to verify outputs.
3. Refer to `screenshots/` for expected outputs.
4. Use `task4_submission_presentation.pptx` for final presentation.

✅ Ready to submit!
