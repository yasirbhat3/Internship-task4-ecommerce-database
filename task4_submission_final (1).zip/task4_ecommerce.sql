-- Task 4 Internship Submission: E-commerce Database
CREATE DATABASE ecommerce;
USE ecommerce;

-- Customers Table
CREATE TABLE customers (
    customer_id INT PRIMARY KEY,
    name VARCHAR(50),
    email VARCHAR(50),
    phone VARCHAR(15)
);

-- Products Table
CREATE TABLE products (
    product_id INT PRIMARY KEY,
    name VARCHAR(50),
    price DECIMAL(10,2),
    stock INT
);

-- Orders Table
CREATE TABLE orders (
    order_id INT PRIMARY KEY,
    customer_id INT,
    order_date DATE,
    FOREIGN KEY(customer_id) REFERENCES customers(customer_id)
);

-- Order Items Table
CREATE TABLE order_items (
    order_item_id INT PRIMARY KEY,
    order_id INT,
    product_id INT,
    quantity INT,
    FOREIGN KEY(order_id) REFERENCES orders(order_id),
    FOREIGN KEY(product_id) REFERENCES products(product_id)
);

-- Sample Data (small dataset 5–10 rows)
INSERT INTO customers VALUES
(1, 'Alice', 'alice@example.com', '111-222-3333'),
(2, 'Bob', 'bob@example.com', '222-333-4444'),
(3, 'Charlie', 'charlie@example.com', '333-444-5555'),
(4, 'Diana', 'diana@example.com', '444-555-6666');

INSERT INTO products VALUES
(1, 'Laptop', 75000.00, 5),
(2, 'Headphones', 1500.00, 20),
(3, 'Keyboard', 1200.00, 15),
(4, 'Mouse', 800.00, 30);

INSERT INTO orders VALUES
(1, 1, '2025-09-20'),
(2, 2, '2025-09-21'),
(3, 1, '2025-09-22');

INSERT INTO order_items VALUES
(1, 1, 1, 1),
(2, 1, 2, 2),
(3, 2, 3, 1),
(4, 3, 4, 3);

-- Example Queries
-- 1. List all customers
SELECT * FROM customers;

-- 2. List all orders with customer names
SELECT o.order_id, c.name, o.order_date
FROM orders o
JOIN customers c ON o.customer_id = c.customer_id;

-- 3. Get total sales amount per order
SELECT o.order_id, SUM(p.price * oi.quantity) AS total_amount
FROM orders o
JOIN order_items oi ON o.order_id = oi.order_id
JOIN products p ON oi.product_id = p.product_id
GROUP BY o.order_id;

-- 4. Show products with stock less than 10
SELECT * FROM products WHERE stock < 10;
